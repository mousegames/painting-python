import pygame as pg
pg.init()

file = input('save as: ')

screen = pg.display.set_mode((800, 400))
pg.display.set_caption('py paint')
player_pos = pg.Vector2(-100, -100)

run = True
while run:
	for event in pg.event.get():
		if event.type == pg.QUIT:
			run = False
		
		if event.type == pg.MOUSEBUTTONDOWN:
			mouse_pos = pg.mouse.get_pos()
			player_pos.x = mouse_pos[0]
			player_pos.y = mouse_pos[1]
		
	keys = pg.key.get_pressed()
	if keys[pg.K_w]:
		player_pos.y -= 0.5
	if keys[pg.K_s]:
		player_pos.y += 0.5
	if keys[pg.K_a]:
		player_pos.x -= 0.5
	if keys[pg.K_d]:
		player_pos.x += 0.5
		
	player_rect = pg.Rect(player_pos.x, player_pos.y, 50, 50)
	pg.draw.rect(screen, (255, 255, 255), player_rect)
	pg.display.flip()

pg.image.save(screen, file)
pg.quit()

